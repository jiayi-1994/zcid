const MS_BASE_URL = process.env.MS_BASE_URL ?? 'http://172.20.18.75:8081';
const MS_USERNAME = process.env.MS_USERNAME ?? '';
const MS_PASSWORD = process.env.MS_PASSWORD ?? '';
const MS_AUTH = process.env.MS_AUTH ?? 'LOCAL';

if (!MS_USERNAME || !MS_PASSWORD) {
  console.error('Missing credentials: set MS_USERNAME and MS_PASSWORD');
  process.exit(1);
}

class CookieJar {
  #cookies = new Map();

  absorb(headers) {
    const raw = headers.get('set-cookie');
    if (!raw) return;
    const parts = raw.split(/,(?=[^;]+?=)/g);
    for (const p of parts) {
      const kv = p.split(';', 1)[0];
      const idx = kv.indexOf('=');
      if (idx <= 0) continue;
      const name = kv.slice(0, idx).trim();
      const value = kv.slice(idx + 1).trim();
      if (!name) continue;
      this.#cookies.set(name, value);
    }
  }

  headerValue() {
    return [...this.#cookies.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
  }
}

async function msFetch(jar, path, opts = {}) {
  const url = `${MS_BASE_URL}${path}`;
  const headers = new Headers(opts.headers ?? {});
  headers.set('Accept', 'application/json');

  const cookie = jar.headerValue();
  if (cookie) headers.set('Cookie', cookie);

  if (opts.csrfToken) headers.set('CSRF-TOKEN', opts.csrfToken);
  if (opts.workspaceId) headers.set('WORKSPACE', opts.workspaceId);
  if (opts.projectId) headers.set('PROJECT', opts.projectId);

  const init = {
    method: opts.method ?? 'GET',
    headers,
    redirect: 'manual',
  };

  if (Object.prototype.hasOwnProperty.call(opts, 'json')) {
    headers.set('Content-Type', 'application/json');
    init.body = JSON.stringify(opts.json);
  }

  const res = await fetch(url, init);
  jar.absorb(res.headers);

  const contentType = res.headers.get('content-type') ?? '';
  const text = await res.text();
  const isJson = contentType.includes('application/json') || text.startsWith('{') || text.startsWith('[');

  return {
    status: res.status,
    headers: res.headers,
    bodyText: text,
    bodyJson: isJson ? safeJsonParse(text) : undefined,
    redirected: res.status >= 300 && res.status < 400,
    location: res.headers.get('location') ?? undefined,
  };
}

function safeJsonParse(s) {
  try {
    return JSON.parse(s);
  } catch {
    return undefined;
  }
}

async function login(jar) {
  const res = await msFetch(jar, '/signin', {
    method: 'POST',
    json: { username: MS_USERNAME, password: MS_PASSWORD, authenticate: MS_AUTH },
  });

  if (res.status !== 200) {
    throw new Error(`signin failed: status=${res.status} body=${res.bodyText}`);
  }

  const body = res.bodyJson;
  if (!body || typeof body !== 'object') {
    throw new Error(`signin returned non-json: ${res.bodyText}`);
  }
  if (!body.success) {
    throw new Error(`signin unsuccessful: ${body.message}`);
  }

  const csrfToken = body.data?.csrfToken ?? body.data?.csrf ?? undefined;
  const user = body.data?.user ?? body.data ?? undefined;

  return { csrfToken, user };
}

async function main() {
  const jar = new CookieJar();
  const { csrfToken } = await login(jar);
  if (!csrfToken) {
    console.warn('Warning: csrfToken not found in /signin response; you may need to capture it from UI/localStorage.');
  }

  // currentUser is useful to confirm session is valid.
  const cur = await msFetch(jar, '/currentUser', {
    csrfToken: csrfToken ?? '1',
  });
  if (cur.status !== 200) {
    throw new Error(`currentUser failed: status=${cur.status} body=${cur.bodyText}`);
  }

  // List projects
  const projects = await msFetch(jar, '/project/listAll', {
    csrfToken: csrfToken ?? '1',
  });
  if (projects.status !== 200) {
    throw new Error(`project/listAll failed: status=${projects.status} body=${projects.bodyText}`);
  }
  const ph = projects.bodyJson;
  const projectList = Array.isArray(ph?.data) ? ph.data : [];
  if (projectList.length === 0) {
    console.warn('No projects found in response; inspect body:', projects.bodyText.slice(0, 500));
  }

  const projectId = projectList[0]?.id;
  if (!projectId) {
    throw new Error('Cannot determine projectId from /project/listAll; choose a project explicitly.');
  }

  // List case nodes
  const nodes = await msFetch(jar, `/case/node/list/${encodeURIComponent(projectId)}`, {
    csrfToken: csrfToken ?? '1',
  });
  if (nodes.status !== 200) {
    throw new Error(`case/node/list failed: status=${nodes.status} body=${nodes.bodyText}`);
  }
  const nodeList = Array.isArray(nodes.bodyJson) ? nodes.bodyJson : [];
  const nodeId = nodeList[0]?.id;
  if (!nodeId) {
    throw new Error('Cannot determine nodeId from /case/node/list/{projectId}');
  }

  // Save a sample test case
  const tc = await msFetch(jar, '/test/case/save', {
    method: 'POST',
    csrfToken: csrfToken ?? '1',
    json: {
      projectId,
      nodeId,
      name: 'API创建用例-示例',
      priority: 'P0',
      status: 'Underway',
      tags: 'api,sync',
      prerequisite: '已登录',
      steps: '1. 调用 /signin\n2. 调用 /test/case/save',
      expectedResult: '用例创建成功',
    },
  });

  if (tc.status !== 200) {
    throw new Error(`test/case/save failed: status=${tc.status} body=${tc.bodyText}`);
  }
  console.log('Created test case:', tc.bodyText.slice(0, 500));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
