# Project Skill Summaries

## Story 1.4 - 结构化日志与脱敏引擎

### Skill: Go slog runtime level control
- Use `slog.LevelVar` as shared runtime switch.
- Keep `Init(level)` tolerant (fallback to info) and `SetLevel(level)` strict (return error on invalid input).
- Expose `CurrentLevel()` for admin API and diagnostics.

### Skill: Safe logging with recursive masking
- Apply masking to both log message and attrs.
- Detect sensitive keys (`password/secret/token/apikey/...`) and replace with `***`.
- Recursively process grouped attrs via `slog.GroupValue(...)` to avoid nested leaks.

### Skill: Request-level observability in Gin
- Put `RequestID` middleware before access logging.
- Emit request logs after `c.Next()` with status + latency + route path.
- Include `requestId` in access and panic recovery logs for correlation.

### Skill: Config override hardening
- Keep defaults in code, YAML for baseline, ENV as highest priority.
- Validate critical env override paths with tests (`SERVER_PORT`, `SERVER_LOG_LEVEL`).

### Skill: Story completion checklist (backend)
- Update story artifact status to `review`.
- Update `files/implementation-artifacts/sprint-status.yaml` story state.
- Run both `go test ./... -v` and `go build ./...` before marking complete.

## Story 1.5 - Redis 连接与缓存基础层

### Skill: Cache wrapper error contracts
- Return typed `ErrCacheMiss` for misses so callers can branch into DB fallback.
- Return wrapped operational errors for Redis/network failures; never panic on cache operations.
- Validate nil client early in each method to keep failure mode explicit.

### Skill: Redis key strategy
- Use a shared prefix strategy (`keyPrefix + key`) to keep namespaces clear.
- Keep TTL policy centralized with `defaultTTL`, and allow per-call override.

### Skill: Availability-aware cache behavior
- Treat cache as best-effort infra: failures should be recoverable by upper layers.
- Keep readiness using direct Redis ping, but application paths should degrade gracefully.

## Story 1.7 - 前端设计系统基础

### Skill: Status style single source of truth
- Define a centralized `STATUS_MAP` to standardize status color/bg/icon/label tokens across pages.
- Keep status definitions typed (`StatusStyle`) so downstream components consume consistent fields.

### Skill: Error boundary retry test pattern
- For React 19 concurrent rendering, use a controlled throw flag in test setup and toggle it before retry click to avoid false unhandled error recovery paths.
- Assert fallback (`role="alert"`) and retry button visibility before triggering retry.

### Skill: Lightweight reusable UI primitives
- Keep generic cross-page components in `components/common` (`PageSkeleton`, `PermissionGate`) with minimal props and predictable behavior.
- Add focused tests for each primitive to lock expected render/no-render contracts.

## Story 1.8 - API 客户端自动生成流水线

### Skill: Stabilize OpenAPI codegen pipeline early
- Validate `make swag` + `npm run codegen` chain as part of baseline engineering flow before real business endpoints are added.
- Keep generated client output fixed at `web/src/services/generated` so import paths remain stable across stories.

### Skill: Tooling compatibility over planned flags
- Prefer CLI flags supported by the installed toolchain; remove unsupported `swag` options to keep CI and local runs deterministic.
- Treat generator invocation as executable contract in Makefile/scripts and verify with a real run after changes.

### Skill: Codegen verification pattern
- After regeneration, assert both generated SDK/types files and frontend build success to catch schema-client drift early.
- Even with empty/seed OpenAPI specs, keep generation artifacts committed to confirm pipeline health for upcoming API stories.

## Story 1.9 - Helm Chart 基础骨架

### Skill: Minimal Helm chart structure
- Start with Chart.yaml + values.yaml + _helpers.tpl + deployment/service/configmap templates.
- Keep _helpers.tpl focused: labels, selectorLabels, fullname — avoid over-abstracting at MVP stage.

### Skill: Config-to-values alignment
- Mirror the application config.yaml structure in values.yaml so ConfigMap template renders a valid config file directly.
- Sensitive values (passwords, keys) go through K8s Secret env vars with `optional: true` to avoid hard dependency on Secret existence during development.

### Skill: Helm validation as acceptance gate
- Use `helm lint` (zero errors) + `helm template` (valid manifests) + `helm template --set` (override verification) as the three-step validation for chart stories.